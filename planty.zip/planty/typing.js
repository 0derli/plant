let activeTyping = null;

function startTyping() {
    if (activeTyping) {
        clearTimeout(activeTyping);
        activeTyping = null;
    }
    
    const el = document.getElementById('modalText');
    const full = el.innerText;
    el.innerText = '';
    
    const lines = full.split(/(?<=[.!?])\s+/);
    let lineIdx = 0;
    let charIdx = 0;
    
    function type() {
        if (lineIdx >= lines.length) return;
        
        const line = lines[lineIdx];
        const current = el.innerText;
        
        if (charIdx === 0 && lineIdx > 0) {
            el.innerText = current + ' ';
        }
        
        if (charIdx < line.length) {
            el.innerText = el.innerText + line[charIdx];
            charIdx++;
            activeTyping = setTimeout(type, 50);
        } else {
            lineIdx++;
            charIdx = 0;
            activeTyping = setTimeout(type, 200);
        }
    }
    
    type();
}