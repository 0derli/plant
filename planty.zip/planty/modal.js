const modal = document.getElementById('modalDesc');
const openBtn = document.getElementById('openDesc');
const closeBtn = document.querySelector('.close');

function openModal() {
    modal.style.display = 'flex';
    startTyping();
}

function closeModal() {
    modal.style.display = 'none';
    if (activeTyping) {
        clearTimeout(activeTyping);
        activeTyping = null;
    }
}

openBtn.addEventListener('click', openModal);
closeBtn.addEventListener('click', closeModal);

window.addEventListener('click', (e) => {
    if (e.target === modal) {
        closeModal();
    }
});